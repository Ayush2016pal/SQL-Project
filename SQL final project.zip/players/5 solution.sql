select bowler, 
       sum(case when is_wicket = 1 then 1 else 0 end) as wickets, 
       count(ball) as balls_bowled,
       case 
           when sum(case when is_wicket = 1 then 1 else 0 end) > 0 
           then count(ball) / sum(case when is_wicket = 1 then 1 else 0 end)
           else null  -- Return NULL or 0 if no wickets are taken
       end as strike_rate
from ball
group by bowler
having count(ball) >= 500
order by strike_rate asc
limit 10;
