select fielder as wicketkeeper, 
       count(*) as dismissals,
       sum(batsman_runs) as total_runs,
       (sum(batsman_runs) * 100.0 / count(ball)) as strike_rate
from ball
where dismissal_kind in ('caught', 'stumped')
group by fielder
order by dismissals desc, strike_rate desc
limit 2;

