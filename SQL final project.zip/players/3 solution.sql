select batsman, 
       sum(case when total_runs >= 4 then total_runs else 0 end) as boundary_runs,
       count(distinct id) as seasons_played
from ball
group by batsman
having count(distinct id) >= 2
order by boundary_runs desc
limit 10;
