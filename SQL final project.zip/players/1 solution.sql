select batsman, 
       sum(batsman_runs) as total_runs, 
       count(ball) as balls_faced, 
       (sum(batsman_runs) / count(ball)) as average,
       count(distinct id) as seasons_played
from ball
group by batsman
having count(distinct id) >= 2
order by average desc
limit 10;

