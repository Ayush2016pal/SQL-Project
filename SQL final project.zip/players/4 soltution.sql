select bowler, 
       count(ball) as balls_bowled, 
       sum(total_runs) as runs_conceded,
       (sum(total_runs) / (count(ball) / 6.0)) as economy
from ball
group by bowler
having count(ball) >= 500
order by economy asc
limit 10;
