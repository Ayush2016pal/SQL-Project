with batsman_stats as (
    select batsman, count(ball) as balls_faced, 
           sum(batsman_runs) as total_runs, 
           (sum(batsman_runs) * 100.0 / count(ball)) as batting_strike_rate
    from ball
    group by batsman
    having count(ball) >= 500
), bowler_stats as (
    select bowler, count(ball) as balls_bowled, 
           sum(total_runs) as runs_conceded,
           (sum(total_runs) / (count(ball) / 6.0)) as bowling_economy
    from ball
    group by bowler
    having count(ball) >= 300
)
select b.batsman, b.balls_faced, b.batting_strike_rate, w.balls_bowled, w.bowling_economy
from batsman_stats b
join bowler_stats w on b.batsman = w.bowler
order by batting_strike_rate desc
limit 10;

